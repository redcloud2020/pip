package com.uni.pip.config;

/**
 * Created by Sammy Shwairy on 2/28/2016.
 */
public interface Config {

    String URL = "http://deerail.com/PIPApi";


}
